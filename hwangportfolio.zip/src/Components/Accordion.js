import React, { useCallback, useRef, useState } from 'react'
import { styled } from 'styled-components'

const Container = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  width : 30vw;
  border-radius: 4px;
  border: 1px solid silver;
`

const Header = styled.div`
  display: flex;
  align-items: center;
  cursor: pointer;
  height: 32px;
  justify-content: space-between;
  margin: 0 10px;
`

const Button = styled.div`

  font-size: 14px;
`
const ContentsWrapper = styled.div`
  height: 0;
  width: inherit;
  overflow: hidden;
  transition: height 0.35s ease, background 0.35s ease;
`

const Contents = styled.div`
  padding: 0.1px;
`

const Accordion = ({header, content}) => {
  const parentRef = useRef(null);
  const childRef = useRef(null);
  const [isCollapse, setIsCollapse] = useState(false);

  const handleButtonClick = useCallback(
    (event) => {
      event.stopPropagation();
      if (parentRef.current === null || childRef.current === null) {
        return;
      }
      if (parentRef.current.clientHeight > 0) {
        parentRef.current.style.height = "0";
        parentRef.current.style.background = "white";
      } else {
        parentRef.current.style.height = `${childRef.current.clientHeight}px`;
        parentRef.current.style.background = "lightgray";
      }
      setIsCollapse(!isCollapse);
    },
    [isCollapse]
  );

  const parentRefHeight = parentRef.current?.style.height ?? "0px";
  const buttonText = parentRefHeight === "0px" ? "열기" : "닫기";

  return (
    <Container>
      <Header onClick={handleButtonClick}>
        {header}
        <Button>{buttonText}</Button>
      </Header>
      <ContentsWrapper ref={parentRef}>
        <Contents ref={childRef} >{content}</Contents>
      </ContentsWrapper>
    </Container>
  )
}

export default Accordion
