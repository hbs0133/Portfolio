import React,{useState} from 'react'
import { styled } from 'styled-components'
import Modal from './Modal'

const Container = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap : 8px;
` 
const Img = styled.div`
  img{
    width :500px;
    height : 400px;
  }
`
const Title = styled.div`
  margin-top : 0px;
`

const Date =styled.div`

`
const Stack = styled.div`

`
const ProjectItem = ({item}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const ModalHandler = () => {
    setIsModalOpen(!isModalOpen);
  };
  return (
    <>
    <Container onClick={ModalHandler}>
      <Img><img src={item.img} /></Img>
      <Title>{item.title}</Title>
      <Date>{item.date}</Date>
      <Stack>{item.stack}</Stack>
    </Container>
    <Modal isOpen={isModalOpen} ModalHandler={ModalHandler} item={item} />
    </>
  )
}

export default ProjectItem
