import React from 'react'
import { styled } from 'styled-components'
import { useNavigate } from 'react-router-dom'

const Container = styled.div`
  display: flex;
  position: relative;
  gap : 120px;
  border: 2px solid #000;
  border-top : none;
  padding : 10px 200px;
  &::before{
    content : "";
    width : 1px;
    height : 70px;
    position: absolute;
    border-left: 2px solid #000;
    left : -2px;
  }
  &::after{
    content : "";
    width : 1px;
    height : 70px;
    position: absolute;
    border-left: 2px solid #000;
    right : -3px;
  }
`

const Link = styled.div`
  cursor : pointer;
  font-weight: bold;
  font-size : 28px;
  transition: 0.3s;
  font-family: 'MYYeongnamnu';
  &:hover{
    color : gray;
  }
`


const Gnb = () => {
  const navigate = useNavigate()
  return (
    <Container>
      <Link onClick={() => navigate("/project")} >Project</Link>
      <Link onClick={() => navigate("/about")}>About</Link>
      <Link onClick={() => navigate("/contact")} >Contact</Link>
    </Container>
  )
}

export default Gnb
