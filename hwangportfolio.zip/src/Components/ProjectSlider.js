import React, { useEffect, useState } from 'react'
import { styled } from 'styled-components';
import { useNavigate } from 'react-router-dom';


const Container = styled.div`
  position: relative;
  width: 60vw;
  height: 55vh;
  overflow: hidden;
  box-shadow: 5px 5px 10px #999;
  border-radius: 4px;
`;

const Image = styled.img`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  transition: opacity 0.8s ease;
  opacity: ${({ isCurrent }) => (isCurrent ? 1 : 0)};
`;



const ProjectSlider = ({images}) => {
const navigate = useNavigate();


const [currentImgIndex, setCurrentImgIndex] = useState(0)

const nextSlide = () => {
  setCurrentImgIndex((prevIndex) => (prevIndex + 1) % images.length);
};

useEffect(() => {
  const sliderInterval = setInterval(nextSlide, 2500)

  return () => {
    clearInterval(sliderInterval)
  };
}, [images])


  return (
    <Container onClick={() => navigate("/project")}>
      {images.map((image, index) => (
        <Image key={index} src={image} isCurrent={index === currentImgIndex} />
      ))}
    </Container>
  )
}

export default ProjectSlider
