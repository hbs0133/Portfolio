import { Route, Routes } from "react-router-dom";
import Home from "./Pages/Home";
import Project from "./Pages/Project";
import About from "./Pages/About";
import Contact from "./Pages/Contact";
import Loading from "./Pages/Loading";
import './App.css'
import { styled } from "styled-components";


//이미지
import rafSimoms from './Img/rafsimons.png'
import netflix from './Img/netflix.png'
import diary from './Img/diary.png'
import todoList from './Img/todolist.png'

const Wrap = styled.div`
  font-family: 'Pretendard-Regular';
`

function App() {


  const images = [
    rafSimoms,
    netflix,
    diary,
    todoList,
  ];


  return (
    <Wrap>
      <Routes>
        <Route path="/" element={<Loading />}></Route>
        <Route path="/home" element={<Home images={images} />}></Route>
        <Route path="/project" element={<Project images={images} />}></Route>
        <Route path="/about" element={<About />}></Route>
        <Route path="/contact" element={<Contact />}></Route>
      </Routes>
    </Wrap>
  );
} 

export default App;
