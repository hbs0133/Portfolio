import React from 'react'
import { styled } from 'styled-components'
import Logo from '../Components/Logo'
import Gnb from '../Components/Gnb'
import Accordion from '../Components/Accordion'

const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap : 50px;
`
const AboutMeBox = styled.div`
  display: flex; 
  gap : 50px;
`
const AboutMeImg = styled.div`

`
const AboutMeText = styled.div`

`

const SkillsBox = styled.div`

`

const About = () => {
  return (
    <Container>
      <Logo />
      <Gnb />
      <AboutMeBox>
        <AboutMeImg><img src='http://via.placeholder.com/300x600' /></AboutMeImg>
        <AboutMeText>텍스트</AboutMeText>
      </AboutMeBox> 
      <SkillsBox>
        <Accordion header={"HTML"} content={"콘텐츠1"}/>
        <Accordion header={"CSS & SASS"} content={"콘텐츠2"}/>
        <Accordion header={"JavaScript"} content={"콘텐츠3"}/>
      </SkillsBox>
    </Container>
  )
}

export default About
