import React from 'react'
import Logo from '../Components/Logo'
import { styled } from 'styled-components'
import ProjectSlider from '../Components/ProjectSlider'
import '../App.css'
import { useNavigate } from 'react-router-dom'

const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap : 50px;
`
const LinkBox = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  border: 5px solid #000;
  border-top: none;
  border-bottom: none;
  font-size : 60px;
  div:last-child{
    border-top: 5px solid #000;
  }
`
const Link = styled.div`
  cursor: pointer;
  padding: 10px 300px;
  font-family: 'MYYeongnamnu';
  font-weight: 400;
  transition: 0.3s;
  &:hover{
    color : gray;

  }
`

const Home = ({images}) => {
  const navigate = useNavigate()
  return (
    <Container>
      <Logo />
      <ProjectSlider images={images} />
      <LinkBox>
        <Link onClick={() => navigate("/about")}>About</Link>
        <Link onClick={() => navigate("/contact")}>Contact</Link>
      </LinkBox>
    </Container>
  )
}

export default Home
