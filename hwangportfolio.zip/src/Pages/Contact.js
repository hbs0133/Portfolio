import React from 'react'

const Contact = () => {
  return (
    <div>
      컨택트페이지
    </div>
  )
}

export default Contact
