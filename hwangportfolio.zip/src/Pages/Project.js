import React, { useEffect, useState } from 'react'
import { styled } from 'styled-components'
import Logo from '../Components/Logo'
import ProjectSlider from '../Components/ProjectSlider'
import ProjectItem from '../Components/ProjectItem'

const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap : 50px;
`
const ProjectBox = styled.div`
  display : grid;
  margin-top : 100px;
  grid-template-columns: repeat(3, 1fr);
  grid-gap : 0px 20px;
`


const Project = ({images}) => {
  const [projectList,setProjectList] = useState([]);
  const getProduct = async () => {
    let url = `http://localhost:3004/projects`
    let response = await fetch(url);
    let data = await response.json();
    setProjectList(data)
  }
  useEffect(()=> {
    getProduct();
  },[])
  

  return (
    <>
    <Container>
      <Logo />
      <ProjectSlider images={images} />
      <ProjectBox>
        {projectList.map((item)=> (
          <ProjectItem item={item}/>
        ))}
      </ProjectBox>
    </Container>
    </>
  )
}

export default Project
